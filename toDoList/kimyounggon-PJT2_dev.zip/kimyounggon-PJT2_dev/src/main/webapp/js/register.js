const todoTitle = document.querySelector("#todo_title");
const todoPersonName = document.querySelector("#todo_person_name");
const radios = document.querySelectorAll("#radio_container>input");

const clearButton = document.querySelector("#clear_button");
clearButton.addEventListener("click", allClear);

const registerForm = document.querySelector("#register_form");
registerForm.onsubmit = submitWithBody;

function allClear() {
	todoTitle.value = "";
	todoPersonName.value = "";

	radios.forEach(function(radio) {
		radio.checked = false;
	});
}

function submitWithBody() {
	let radioValue;
	radios.forEach(function(radio) {
		if (radio.checked) {
			radioValue = radio.value;
			return;
		}
	})

	const jsonData = {
		"title": todoTitle.value,
		"name": todoPersonName.value,
		"sequence": radioValue
	}

	let httpRequest = new XMLHttpRequest();

	httpRequest.onload = handleHttpStatus;

	httpRequest.open("POST", "todo");
	httpRequest.send(JSON.stringify(jsonData));
	return false;

	function handleHttpStatus() {
		switch (httpRequest.status) {
			case 200:
				window.location = httpRequest.responseURL;
				break;
			case 205:
				alert("할일 등록에 실패하였습니다!");
				allClear();
				break;
			case 405:
				window.location = "/todolist/method_error.html";
				break;
			case 500:
				window.location = "/todolist/server_error.html";
				break;
		}
	}
}