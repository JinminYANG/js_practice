const allUpdateButtons = document.querySelectorAll(".update_button");

allUpdateButtons.forEach(button => button.addEventListener("click", function(event) {
	ajaxToServer(event.target);
}));

const doingList = document.querySelector("#DOING");
const doneList = document.querySelector("#DONE");

function ajaxToServer(button) {
	let json = {
		"id": button.id,
		"type": button.closest("section").id
	}

	let httpRequest = new XMLHttpRequest();

	httpRequest.onload = handleResponse;

	httpRequest.open("PATCH", "todo/type", true);
	httpRequest.send(JSON.stringify(json));

	function handleResponse() {
		if (httpRequest.response === "success") {
			moveTodo(button);
			return;
		}
		if (httpRequest.response === "fail") {
			alert("업데이트에 실패하였습니다");
			return;
		}
		if (httpRequest.status === 500) {
			window.location = "/todolist/server_error.html";
			return;
		}
	}
}

function moveTodo(button) {
	let target;
	let buttonType = button.closest("section").id;

	if (buttonType === "TODO") {
		target = doingList;
	} else if (buttonType === "DOING") {
		button.style.visibility = "hidden";
		target = doneList;
	} else {
		return;
	}

	target.appendChild(button.closest("article"));
}